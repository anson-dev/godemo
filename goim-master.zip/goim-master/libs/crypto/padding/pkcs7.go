package padding

var (
	// difference with pkcs5 only block must be 8
	PKCS7 = &pkcs5{}
)
